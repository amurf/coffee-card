"use strict";
function handler(event, context) {
    console.log('Hello World');
}
exports.handler = handler;
